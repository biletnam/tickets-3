<?php
//-*-coding: utf-8 -*-
print(__FILE__);
?>