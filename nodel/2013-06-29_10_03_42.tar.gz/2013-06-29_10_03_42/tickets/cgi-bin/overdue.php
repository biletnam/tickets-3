<?php
$host="localhost";
$user="infotur_tur";
$parol="caxhgx6e";
$db="infotur_ts";
mysql_connect($host,$user,$parol);
mysql_query("USE ".$db);
mysql_query("SET NAMES 'utf8'");
$query="UPDATE booking  set status=2 where time < '".date("Y-m-d H:i:s",mktime(0,0,0,date("m"),date("d")-3,date("Y")))."' and status=0";
$res=mysql_query($query);
$num_row=mysql_affected_rows($res);
$hFile=fopen("/var/www/infotur/data/www/tickets.777tur.com/logs/overdue.log","a");
$strLog=date("Y-m-d H:i:s");
//$strLog.=" ".$query."\n";
if(mysql_errno($res))
{
	$strLog.=" Mysql ERROR ".mysql_error()."\n";
}
else
{
	$strLog.="Списание просроченных прошло успешно: списано ".$num_row." заказов\n";
};
fwrite($hFile,$strLog);
fclose($hFile);
?>