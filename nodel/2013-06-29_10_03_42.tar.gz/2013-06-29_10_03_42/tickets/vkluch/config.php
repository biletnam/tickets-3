<?php
//-*-coding: utf-8 -*-
class Config{
	public static $dir0="/var/www/infotur/data/www/tickets.777tur.com";
	public static $user="infotur_tur";
	public static $db="infotur_ts";
	public static $host="localhost";
	public static $parol="caxhgx6e";

}