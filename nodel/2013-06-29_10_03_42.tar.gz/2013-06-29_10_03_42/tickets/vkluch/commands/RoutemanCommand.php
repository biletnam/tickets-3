<?php
//-*-coding: utf-8 -*-
class MethodNotFoundException extends Exception
{
};
class RoutemanCommand extends Command
{
	private $reys;
	public function execute(CommandContext $context)
	{
		require_once("classRoute.php");
		$saver1=new saver();
		$this->reys=$saver1->getCache("reys");
		if(!$this->reys)
		{
			$this->reys=new oReys();
		};
		$inputs=iData::getRealize();
		$aDD=$inputs->getAllData();
		if (is_callable(array($this,$context->getParam("act"))))
		{
			return call_user_func_array(array($this,$context->getParam("act")),array("aData",$aDD));
		}else
		{
			throw new MethodNotFoundException("method ".$context->getParam("act")." not found in object ".$this);
		};
		$saver1->saveCache($this->reys);
	}
	public function __call($method,$args)
	{
		
		return call_user_func_array(array($this->reys,$method),array($args));
	}
}