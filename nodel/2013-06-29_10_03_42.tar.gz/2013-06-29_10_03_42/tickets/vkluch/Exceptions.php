<?php
class MethodNotFoundException extends Exception
{
}