<?php
//-*-coding: utf-8 -*-
class RouteManDB
{
	const SEL=",";//разделитель пунктов в списке
	public function getroute()
	{
	//получение маршрута из БД по пункту отправления и  прибытия
		$aInputs=func_get_arg(0);
		$point1=$aInputs[1]["point1"];
		$point2=$aInputs[1]["point2"];
		$query="SELECT * FROM routes as t1,routes as t2 WHERE (t1.point ='".$point1."') AND(t2.point ='".$point2."') AND (t1.idroute=t2.idroute) AND(t1.idpoint<t2.idpoint)";
		
		//print($query);
		$res=mysql_query($query);
		
		$aData= mysql_fetch_assoc($res);
		//print_r($aData);
		return $aData["idroute"];
	}
	protected function getReys($idRoute,$date)
	{
	//получение рейса по маршруту и дате
		require_once("Reys.php");
		require_once("avtobus.php");
		$aTemp=explode(".",$date);
		$date=$aTemp[2]."-".$aTemp[1]."-".$aTemp[0];
		$query="SELECT * FROM reyses WHERE idroute='".$idRoute."' AND date='".$date."'";
		$res=mysql_query($query);
		$aData=mysql_fetch_assoc($res);
		$reys=new Reys();
		if(!$aData)
		{
		
			$query="SELECT * FROM routesetting WHERE idroute=$idRoute";
			$res=mysql_query($query);
			$aData=mysql_fetch_assoc($res);
		}
		else
		{
		
		
			$reys->setIdReys($aData["id"]);
			
		
		};
		$reys->initAvtobus($aData["typeavtobus"]);
		$avtobus=$reys->getAvtobus();
		if($aData["free_places"])
		{
			$aR=explode(self::SEL,$aData["free_places"]);
			$avtobus->freeking($aR);
		};
		if($aData["booked_places"])
		{
			$aR=explode(self::SEL,$aData["booked_places"]);
			$avtobus->reserving($aR);
		};
		if($aData["reserved_places"])
		{
			$aR=explode(self::SEL,$aData["reserved_places"]);
			$avtobus->reserving($aR);
		};
		
		//$avtobus->testPlaces();
		return $reys;
	}
	public function getPrice($idRoute,$point1,$point2)
	{
	$rest=$idRoute % 2;
		if($rest==0)
		{
			$idRouteP=$idRoute-1;
		}else
		{
			$idRouteP=$idRoute;
		};
		$query="SELECT * FROM routes WHERE point='".$point1."' AND idroute='".$idRouteP."'";
			$res=mysql_query($query);
			$aData=mysql_fetch_assoc($res);
			$pr1=$aData["price"];
			$query="SELECT * FROM routes WHERE point='".$point2."' AND idroute='".$idRouteP."'";
			$res=mysql_query($query);
			$aData=mysql_fetch_assoc($res);
			
			$pr2=$aData["price"];
			if($rest==0)
			{
				$znak=substr($pr2,0,1);
				switch ($znak)
				{
					case "+":
						$price0=$pr1+substr($pr2,1);
					break;
					case "-":
						$price0=$pr1-substr($pr2,1);
					break;
					case "0":
						$price0=$pr1;
					break;
					default:
						$price0=$pr1;
				};
			}else
			{
				$znak=substr($pr1,0,1);
				switch ($znak)
				{
					case "+":
						$price0=$pr2+substr($pr1,1);
					break;
					case "-":
						$price0=$pr2-substr($pr1,1);
					break;
					case "0":
						$price0=$pr2;
					break;
					default:
						$price0=$pr2;
				};
			};
		return $price0;
	}
	public function getplaces()
	{
		$aInputs=func_get_arg(0);
		$date=$aInputs[1]["date"];
		$idRoute=$this->getroute(array("1"=>array("point1"=>$aInputs[1]["point1"],"point2"=>$aInputs[1]["point2"])));
		//print($idRoute);
		if($idRoute)
		{
		$reys=$this->getReys($idRoute,$date);
		$avtobus=$reys->getAvtobus();
		$aPlaces=$avtobus->getPlaces();
		//var_dump($aPlaces);
		$num=count($aPlaces);
		$strOut="var aPlaces=new Array(";
		for($i=1;$i<=$num;$i++)
		{
			
				$strOut.=$aPlaces[$i].",";
			
			
		};
		
		$price0=$this->getPrice($idRoute,$aInputs[1]["point1"],$aInputs[1]["point2"]);
		//$handle=fopen("/var/www/infotur/data/www/tickets.777tur.com/data/route.log","a");
	//	fwrite($handle,$strOut);
	//	fclose($handle);
		
		$strOut=substr($strOut,0,-1).");var idRoute=".$idRoute."; var idReys=".$reys->getIdReys()."; var typeAvtobus=".$avtobus->getProp('type')."; var tarif1=".$price0;
		print($strOut);
		}else
		{
			print("var aPlaces=false");
		}
	}
	public function checkReys(Reys $reys)
	{
		$query="SELECT * FROM `reyses` WHERE `idroute`=".$reys->idRoute." AND `date`='".$reys->date."'";
		$res=mysql_query($query);
		$aData=mysql_fetch_assoc($res);
		if($aData["id"])
		{
			return $aData["id"];
		}
		else
		{ 
			return false;
		}
	}
	public function saveReysBD(Reys $reys)
	{
		$avtobus=$reys->getAvtobus();
		$places=$avtobus->getPlaces();
		$freePlaces="";
		$bookPlaces="";
		$reservPlaces="";
		foreach($places as $num=>$type)
		{
			switch ($type)
			{
				case Avtobus::FREE:
					$freePlaces.=$num.",";
				break;
				case Avtobus::BOOKED:
					$bookPlaces.=$num.",";
				break;
				case Avtobus::RESERVED:
					$reservPlaces.=$num.",";
				
			}
		}
		$id=checkReys($reys);
		if($id)
		{
			$query="UPDATE reyses SET `freeplaces`='".$freePlaces."',`bookplaces`='".$bookPlaces."',`reservplaces`='".$reservPlaces."',`typeavtobus`=".$avtobus->getType()." WHERE id=".$id;
			
		}
		else
		{
			$route=$reys->getRoute;
			$query="INSERT INTO `reyses` (`idroute`,`date`,`freeplaces`,`bookplaces`,`reservplaces`,`typeavtobus`) VALUES(".$route->getId().",'".$reys->getDate()."','".$freePlaces."','".$bookPlaces."','".$reservPlaces."','".$avtobus->getType()."')";
		}
		$res=mysql_query($query);
	}
	public function getdates()
	{
		$aInputs=func_get_arg(0);
		$query="SELECT * FROM routes as t1,routes as t2 WHERE (t1.point ='".$aInputs[1]["point1"]."') AND(t2.point ='".$aInputs[1]["point2"]."') AND (t1.idroute=t2.idroute) AND(t1.idpoint<t2.idpoint)";
		$res=mysql_query($query);
		$aData=mysql_fetch_assoc($res);
		$rest=$aData["idroute"] % 2;
		if($rest==0)
		{
			$query="SELECT days,dop_date FROM routes WHERE idroute=".$aData["idroute"]." AND idpoint=1";
		}
		else
		{
			$query="SELECT days,dop_date FROM routes WHERE idroute=".$aData["idroute"]." AND price=0";
		};
		$res=mysql_query($query);
		$aData2=mysql_fetch_assoc($res);
		$aStrsDays=explode(",",$aData2["days"]);
		$aDates=array("06"=>array(),"07"=>array(),"08"=>array());
		require_once("funcDates.php");
		$toolDate=new funcDates();
		foreach($aStrsDays as $num=>$day)
		{
			$aDates["06"]=array_merge($aDates["06"],$toolDate->getDates($day,6,2013));
			$aDates["07"]=array_merge($aDates["07"],$toolDate->getDates($day,7,2013));
			$aDates["08"]=array_merge($aDates["08"],$toolDate->getDates($day,8,2013));
			
		};
		$aStrsDays=explode(",",$aData2["dop_date"]);
		foreach($aStrsDays as $num=>$strDate)
		{
			if(trim($strDate))
			{
				$aTemp=explode(".",$strDate);
				array_push($aDates[$aTemp[1]],$aTemp[0]);
			};
		};
		$aTemp=array_unique($aDates["06"]);
		$aDates["06"]=$aTemp;
		$aTemp=array_unique($aDates["07"]);
		$aDates["07"]=$aTemp;
		$aTemp=array_unique($aDates["08"]);
		$aDates["08"]=$aTemp;
		$aTemp=$toolDate->setRange(date("d"),32,$aDates["06"]);
		$aDates["06"]=$aTemp;
		sort($aDates["06"]);
		sort($aDates["07"]);
		sort($aDates["08"]);
		$str1="var oDates={'06':new Array('".implode("','",$aDates["06"])."'),'07':new Array('".implode("','",$aDates["07"])."'),'08':new Array('".implode("','",$aDates["08"])."')};";
		
			
		print($str1);
		
	}
}