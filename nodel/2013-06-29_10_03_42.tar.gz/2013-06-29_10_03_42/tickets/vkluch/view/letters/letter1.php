Вы заказали билет на автобус 
<?php
print($this->fields["point1"]->getValue();

?>