<?php
//-*-coding: utf-8 -*-
//основной контроллер
class Komandor
{
	
}