<?php
//-*-coding: utf-8 -*-
abstract class Command
{
	abstract public function execute(CommandContext $context);
}
class CommandContext
{
	private $params=array();
	private $errors="";
	public function __construct()
	{
		$inputs=iData::getRealize();
		$params=$inputs->getAllData();
	}
	public function addParam($key,$value)
	{
		$this->params[$key]=$value;
	}
	public function getParam($key)
	{
		return $this->params[$key];
	}
}
class CommandNotFoundException extends \Exception
{
}
class CommandFactory2
{
	private static $dir="/vkluch/commands";
	public static function getCommand($act="default")
	{
		if(preg_match("/\W/",$act))
		{
			throw new Exception("notAvailable Chars");
		};
		$class=UCFirst(strtolower($act))."Command";
		$inputs=iData::getRealize();
		$file=$inputs->getData("dir0").self::$dir."/".$class.".php";
		$class=$class;
		if(!file_exists($file))
		{
			throw new CommandNotFoundException("file ".$file." not found");
		};
		require_once($file);
		if(!class_exists($class))
		{
			print($class);
			throw new CommandNotFoundException("class ".$class." not found");
		};
	
		
		$cmd=new $class();
		return $cmd;
	}
}
class CommandFactory
{
	private static $dir="/vkluch/commands";
	public static function getCommand($act="Default")
	{
		if(preg_match("/\W/",$act))
		{
			throw new Exception("notAvailable Chars");
		};
		$class=UCFirst(strtolower($act))."Command";
		$inputs=iData::getRealize();
		$file=$inputs->getData("dir0").self::$dir."/".$class.".php";
		$class=$class;
		if(!file_exists($file))
		{
			throw new CommandNotFoundException("file ".$file." not found");
		};
		require_once($file);
		if(!class_exists($class))
		{
			print($class);
			throw new CommandNotFoundException("class ".$class." not found");
		};
	
		
		$cmd=new $class();
		return $cmd;
	}
}