function addEv(elem,type,handle)
{
handler=function (e)
{
	if (!e.target) {
	e.target = e.srcElement;
	};
	handle(e);
};
	if (elem.addEventListener)
	elem.addEventListener(type, handler, true)
	else if (elem.attachEvent)
	elem.attachEvent("on" + type, handler);
};
function trim(str)
{
	var regB=/^\s+/;
	var regE=/\s+$/;
	var str1=str.replace(regB,"");
	var str2=str1.replace(regE,"");
	return str2;
};
function getStyle(el, cssprop){
    if (window.getComputedStyle) 
    {//Normal
        if (cssprop == 'float') cssprop = 'cssFloat';
	    var css=window.getComputedStyle(el, '');
        return css[cssprop];
    }
    else
    {
        if (el.currentStyle)
        {//IE
            if (cssprop == 'float') cssprop = 'styleFloat';
            return el.currentStyle[cssprop];
        }
    }
};
function set4UA(obj)
{
	var patt=null;
	for (prop in obj)
	{
		patt=new RegExp(prop,"i");
		if (navigator.userAgent.search(patt)!=-1)
		{
			return obj[prop];
		};
	};
	return obj["default"];
};
function remEv(elem,type,handle)
{
	if (elem.removeEventListener)
	elem.removeEventListener(type, handler,true)
	else if (elem.detachEvent)
	elem.detachEvent("on" + type, handler);
};
function bindReady(handler){
	var called = false
	function ready() { // (1)
		if (called) return
		called = true
		handler()
	}
	if ( document.addEventListener ) { // (2)
		document.addEventListener( "DOMContentLoaded", function(){
			ready()
		}, false )
	} else if ( document.attachEvent ) {  // (3)

		// (3.1)
		if ( document.documentElement.doScroll && window == window.top ) {
			function tryScroll(){
				if (called) return
				if (!document.body) return
				try {
					document.documentElement.doScroll("left")
					ready()
				} catch(e) {
					setTimeout(tryScroll, 0)
				}
			}
			tryScroll()
		}

		// (3.2)
		document.attachEvent("onreadystatechange", function(){

			if ( document.readyState === "complete" ) {
				ready()
			}
		})
	}

	// (4)
    if (window.addEventListener)
        window.addEventListener('load', ready, false)
    else if (window.attachEvent)
        window.attachEvent('onload', ready)
    /*  else  // (4.1)
        window.onload=ready
	*/
};
function sendZapros(url,data,func)
{
	try{request=new XMLHttpRequest();}catch(trymicrosoft){try{request=new ActiveObject("Msxm12.XMLHTTP");}catch(othermicrosoft){try {request=new ActiveObject("Microsoft.XMLHTTP");}catch(failed){request=null;}}};
	request.open("POST",url,true);
	request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	var proc=func;
	request.onreadystatechange=function (){if(request.readyState==4){	proc(request.responseText);}};
	request.send(data);
};
function in_array(el,arr)
{
	for (var eA in arr)
	{
		if(el==arr[eA])
		{
			
			return true;
		}
	};
	return false;
};
function _(id)
{
	return document.getElementById(id);
};
function bilet1()
{
	//отправляет запрос на места для прямого билета
	var point1=document.getElementById("inp1").value;
	var point2=document.getElementById("inp2").value;
	if(!in_array(point1,oTT[0]))
	{
		alert("Выберите пункт отправления из выпадающего списка");
		document.getElementById("inp1").focus();
		return false;
	};
	if(!point2)
	{
		alert("Выберите пункт прибытия из выпадающего списка");
		document.getElementById("inp2").focus();
		return false;
	}; 
	var date1=document.getElementById("inp3").value;
	if(date1)
	{
		sendZapros('/routedat/getplaces/?point1='+encodeURI(point1)+'&point2='+encodeURI(point2)+'&date='+date1+'','',test);
	}else
	{
		alert("Выберите дату отправления");
		document.getElementById("inp3").focus();
	};
};
function bilet2()
{
	//отправляет запрос на места для обратного билета
	var point1=document.getElementById("inp8").value;
	var point2=document.getElementById("inp9").value;
	if(!point1)
	{
		alert("Выберите пункт отправления из выпадающего списка");
		document.getElementById("inp8").focus();
		return false;
	};
	if(!point2)
	{
		alert("Выберите пункт прибытия из выпадающего списка");
		document.getElementById("inp9").focus();
		return false;
	}; 
	var date1=document.getElementById("inp3").value;
	var date2=document.getElementById("inp10").value;
	if(date2)
	{
		/*if(date2<date1)
		{
			alert("Дата возвращения не может быть раньше даты отправления: "+date1);
			return false;
		};*/
		sendZapros('/routedat/getplaces/?point1='+encodeURI(point1)+'&point2='+encodeURI(point2)+'&date='+date2+'','',test2);
	}else
	{
		alert("Выберите дату отправления");
		document.getElementById("inp10").focus();
	};
};
function getF1()
{
	//отображает обратный билет
	var podlozhka=document.getElementById("podlozhka");
	var okno=document.getElementById("okno");
	var dopK=set4UA({"firefox":{"sdvig":35,"height":"500px"},"opera":{"sdvig":15,"height":"500px"},"chrome":{"sdvig":5,"height":"520px"},"safari":{"sdvig":5,"height":"520px"},"msie":{"sdvig":15,"height":"480px"},"default":{"sdvig":35,"height":"500px"}});
	var tT=document.getElementById("treys2");
	var func=function (e)
				{
					var oKoords=absPosition(okno);
					var tKoords=absPosition(tT);
					var pKoords=absPosition(podlozhka);
					var dY=getStyle(tT,"marginTop").slice(0,-2);
					var inp=document.getElementById("inp8");
					var point1=_("inp1").value;
					var point2=_("inp2").value;
					if(!point1)
					{
						alert("Выберите пункт отправления из выпадающего списка");
						return false;
					};
					if(!point2)
					{
						alert("Выберите пункт прибытия из выпадающего списка");
						return false;
					}; 
					inp.value=_("inp2").value;
					inp=_("inp9");
					inp.value=_("inp1").value;
					var y0=pKoords.y+oKoords.y-tKoords.y-dY+dopK.sdvig;
					podlozhka.style.top=y0+"px";
					okno.style.height=dopK.height;
					//e.target.style.display="none";
					//remEv(e.target,"click",func);
					//addEv(e.target,"click",getF3());
					
				}
	return func;
};

function outPrice()
{
	//var strPlaces=_('inpplaces1').value;
	var numPlaces=_('inpplaces1').value.split(",").length;
	var price=numPlaces*aTarifs[1];
	if(_('check2').checked)
	{
		_('rticketstr').style.display='none';
		_('rticketitog').style.display='none';
		if(_("inp4").checked)//льготники
		{
			price=Math.floor(price-_('inpdeti').value*aTarifs[1]*0.1);
		};
		
	}else
	{
	
		//есть обратный билет
		price+=_('inpplaces2').value.split(",").length*aTarifs[2];
		if(_("inp4").checked)//льготники
		{
			price=Math.floor(price-_('inpdeti').value*aTarifs[1]*0.1-_('inpdeti').value*aTarifs[2]*0.1);
		};
		
	};
	
	var oText=document.createTextNode(price + " грн.");
	_("outprice").appendChild(oText);
	
};
function getF2()
{
	//отображает личные данные
	var podlozhka=document.getElementById("podlozhka");
	var okno=document.getElementById("okno");
	var dopK=set4UA({"firefox":{"sdvig":-110,"height":"200px"},"opera":{"sdvig":-140,"height":"200px"},"chrome":{"sdvig":-145,"height":"220px"},"safari":{"sdvig":-145,"height":"220px"},"msie":{"sdvig":-150,"height":"200px"},"default":{"sdvig":-110,"height":"200px"}});
	var tT=document.getElementById("persona");
	
	var func=function (e)
				{
					var oKoords=absPosition(okno);
					var tKoords=absPosition(tT);
					var pKoords=absPosition(podlozhka);
					var dY=0;
					
					var y0=pKoords.y+oKoords.y-tKoords.y-dY+dopK.sdvig;
					podlozhka.style.top=y0+"px";
					okno.style.height=dopK.height;
				
					remEv(e.target,"click",func);
				
				}
	return func;
};
function getF3()
{
	//отображает итог
	var podlozhka=document.getElementById("podlozhka");
	var okno=document.getElementById("okno");
	var tT=document.getElementById("resume");
	var dopK=set4UA({"firefox":{"sdvig":-140,"height":"300px"},"opera":{"sdvig":-137,"height":"300px"},"chrome":{"sdvig":-145,"height":"330px"},"safari":{"sdvig":-145,"height":"330px"},"msie":{"sdvig":-1650,"height":"300px"},"default":{"sdvig":-140,"height":"300px"}});
	
	//var heightO=0;
	//var sdvigO=0;
	function checkPersonalData()
	{
		var dFIO=document.getElementById("inp5").value;
		var patt1=new RegExp("[\\sа-яА-Я-]*");
		var aMatches=patt1.exec(dFIO);
		if((dFIO=="")||(aMatches[0]!=dFIO))
		{
			alert("В поле ФИО недопустимые символы");
			return false;
		}
		else
		{
			dFIO=trim(document.getElementById("inp7").value);
			patt1=/[0-9+()-]*/;
			aMatches=patt1.exec(dFIO);
			if((dFIO=="")||(aMatches[0]!=dFIO))
			{
				alert("В поле Телефон недопустимые символы");
				return false;
			}
			else
			{
				dFIO=trim(document.getElementById("inp6").value);
				patt1=/[а-яА-Яa-zA-Z0-9\.-]*@[а-яА-Яa-zA-Z0-9\.-]*/;
				aMatches=patt1.exec(dFIO);
				if((dFIO=="")||(aMatches[0]!=dFIO))
				{
					alert("В поле email недопустимые символы");
					return false;
				}
				else
				{
					return true;
				};
			};
		};
		
	};
	
	/*if((navigator.userAgent.indexOf("Chrome")!=-1)||(navigator.userAgent.indexOf("Safari")!=-1))
					{
						heightO="330px";
						sdvigO=60;
					
					}
					else
					{
						heightO="300px";
						sdvigO=0;
					}*/
	function showData(idinp,idspan)
					{
						var oTextN=document.createTextNode(document.getElementById(idinp).value);
						var oSpanN=document.getElementById(idspan);
						oSpanN.appendChild(oTextN);
					
					}
	var func= function (e)
				{
					if(checkPersonalData())
					{
					/*y0=-1455-sdvigO;
					podlozhka.style.top=y0+"px";
					okno.style.height=heightO;*/
					var oKoords=absPosition(okno);
					var tKoords=absPosition(tT);
					var pKoords=absPosition(podlozhka);
					var dY=0;//getStyle(tT,"marginTop").slice(0,-2);
					
					var y0=pKoords.y+oKoords.y-tKoords.y-dY+dopK.sdvig;
						//patt=new RegExp('msie',"i");
					//	alert(y0);
		
					podlozhka.style.top=y0+"px";
					okno.style.height=dopK.height;
					remEv(e.target,"click",func);
					//e.target.removeEventListener("click",func,true);
					//alert(document.getElementById("inp1").value);
					outPrice();
					showData("inp1","rpoint1");
					showData("inp2","rpoint2");
					showData("inp3","rdate1");
					showData("inpplaces1","rplaces1");
					showData("inp8","rpoint3");
					showData("inp9","rpoint4");
					showData("inp10","rdate2");
					showData("inpplaces2","rplaces2");
					showData("inp5","rfio");
					showData("inp7","rphone");
					showData("inp6","remail");
					//e.target.addEventListener("click",getF4(),true);
					//addEv(e.target,"click",getF3());
					};
				}
	return func;
};
function getF4()
{
	function getFieldValue(id)
	{
		var inp=document.getElementById(id);
		if(inp.value)
		{
			return inp.name+"="+encodeURI(trim(inp.value))+"&";
		}else
		{
			return "";
		}
	};
	function proc2(text)
	{
		var oText=document.createTextNode(text+" Ваш счет действителен в течение 48 часов после заказа. По истечении срока неоплаченные места будут выставлены на продажу.");
		var oOut=_("outmessage");
		oOut.appendChild(oText);
		var butt=_("checkbutt4");
		butt.style.display="none";
		
	};
	return function()
	{
		var strData="";
		strData+=getFieldValue("inp1");
		strData+=getFieldValue("inp2");
		strData+=getFieldValue("inp3");
		strData+=getFieldValue("inp5");
		strData+=getFieldValue("inp6");
		strData+=getFieldValue("inp7");
		strData+=getFieldValue("inp8");
		strData+=getFieldValue("inp9");
		strData+=getFieldValue("inp10");
		strData+=getFieldValue("inpplaces1");
		strData+=getFieldValue("inpplaces2");
		strData+=getFieldValue("id_reys1");
		strData+=getFieldValue("id_reys2");
		strData+=getFieldValue("id_route1");
		strData+=getFieldValue("id_route2");
		strData+=getFieldValue('id_kod');
		var check2=document.getElementById("check2");
		if(check2.hasAttribute("checked"))
		{
			strData+="rticket=1&";
		}
		else
		{
			strData+="rticket=0&";
		};
		if(_('inp4').checked)
		{
			strData+=getFieldValue("inpdeti");
		}else
		{
			strData+="deti=0&";
		};
		strData+="act=getdata";
		//strData=strData.slice(0,-1);
		sendZapros("/mainform/getdata",strData,proc2);
		return true;
	};
};
function getFdeti()
{
	var ddiv=document.getElementById("cont-deti");
	return function (e)
		{
			
			if(e.target.checked)
			{
				ddiv.style.display="block";
			}
			else
			{
				ddiv.style.display="none";
			};
		};
};
function getOneWayTicket(id1,id2)
{
	var okno=document.getElementById(id1);
	var blind=document.getElementById(id2);
	var funcDop=getF1();
	function initButton()
	{
		var but1=document.getElementById("but-yes");
		addEv(but1,"click",yes);
		but1=document.getElementById("but-no");
		addEv(but1,"click",no);
	};
	initButton();
	function show()
				{
					var sSize=screenSize();
					var x0=sSize.w/2-250;
					var y0=sSize.h/2-100+document.body.scrollTop;
					okno.style.top=y0+"px";
					okno.style.left=x0+"px";
					okno.style.display="block";
					blind.style.top=document.body.scrollTop;
					blind.style.display="block";
				};
	function hide()
				{
					okno.style.display="none";
					blind.style.display="none";
					
					
				};
	function no()
				{
					var inp=document.getElementById("check2");
					inp.setAttribute("checked","on");
					toPersona();
					hide();
				};
	function yes()
				{
					var inp=document.getElementById("check2");
					inp.checked=false;
					if(inp.hasAttribute("checked"))
					{
						inp.removeAttribute("checked");
					};
					funcDop();
					hide();
				};			
	return {"show":show,
			"hide":hide,
			"check":function checkOneWayTicket(e)
					{
						if(e.target.checked)
						{
							show();
						}else
						{
							hide();
						};
						
					}
			}
};


function inpReset(id)
{
	var inp=document.getElementById(id);
	inp.value="";
	//if(inp.hasAttribute("readonly"))
	//{
		inp.removeAttribute("readonly");
	//};
};
function inpSetValue(id,value)
{
	var inp=document.getElementById(id);
	inp.value=value;
};
function resetForm()
{
	var aIds=new Array("inp1","inp2","inp3","inp4","inp5","inp6","inp7","inp8","inp9","inp10","inpplaces1","inpplaces2");
	for (var i = 0; i < aIds.length; i++)
	{
		inpReset(aIds[i]);
	};
	inpSetValue("id_route1",-1);
	inpSetValue("id_route2",-1);
	inpSetValue("id_reys1",-1);
	inpSetValue("id_reys2",-1);
	if(avto1)
	{
		var aA1=avto1.getObj();
		aA1.parentNode.removeChild(aA1);
	};
	if(avto2)
	{
		aA1=avto2.getObj();
		aA1.parentNode.removeChild(aA1);
	};
	var podlozhka=document.getElementById("podlozhka");
	podlozhka.style.top="0px";
	podlozhka=document.getElementById("okno");
	podlozhka.style.height="300px";
	podlozhka=document.getElementById("check2");
	podlozhka.removeAttribute("checked");
	location.reload();
	
};
function toPersona()
{
	var podlozhka=document.getElementById("podlozhka");
	var okno=document.getElementById("okno");
	var tT=document.getElementById("persona");
	var dopK=set4UA({"firefox":{"sdvig":-110,"height":"200px"},"opera":{"sdvig":-140,"height":"200px"},"chrome":{"sdvig":-145,"height":"220px"},"safari":{"sdvig":-145,"height":"220px"},"msie":{"sdvig":-150,"height":"200px"},"default":{"sdvig":-110,"height":"200px"}});
	/*if(navigator.userAgent.indexOf("Chrome")!=-1)
					{
						heightO="220px";
						sdvigO=40;
					
					}
					else
					{
						heightO="200px";
						sdvigO=10;
					};
						y0=-1230-sdvigO;
					podlozhka.style.top=y0+"px";
					okno.style.height=heightO;*/
	var oKoords=absPosition(okno);
	var tKoords=absPosition(tT);
	var pKoords=absPosition(podlozhka);
	var dY=0;//getStyle(tT,"marginTop").slice(0,-2);
	
	var y0=1*pKoords.y+oKoords.y-tKoords.y-dY+1*dopK.sdvig;
	
	podlozhka.style.top=y0+"px";
	okno.style.height=dopK.height;
};