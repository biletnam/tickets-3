<?php
//phpinfo();