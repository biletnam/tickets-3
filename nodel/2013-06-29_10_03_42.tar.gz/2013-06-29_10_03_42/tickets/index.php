<?php
//-*-coding: utf-8 -*-
require("vkluch/config.php");
require("vkluch/User.php");
require("controller/controller.php");
Controller::run();